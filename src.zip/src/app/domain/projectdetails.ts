export class ProjectDetails
{
    projectId : number = 0;
    projectName : string = "";
    skill1 : string = "";
    skill2 : string = "";
    skill3 : string = "";
    budget : string ="";
    status : string ="";

}