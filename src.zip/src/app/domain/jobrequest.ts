import { SkipSelf } from "@angular/core";
import { EmployeeDetails } from "./employeedetails";
import { Login } from "./login";
import { ProjectDetails } from "./projectdetails";

export class JobRequest
{
 
  jobId : number = 0;
  skill1 : string = "";
  skill2 : string = "";
  skill3 : string = "";
  count : number = 0;
  status : string = '';
  budget : number = 0;
  
  projectDetails : ProjectDetails = new ProjectDetails();
  employeeDetails : EmployeeDetails = new EmployeeDetails();
  
}