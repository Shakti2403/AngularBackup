export class JobRequest
{

  job_id: number = 0;
   skill_1: string = "";
   skill_2: string = "";
   skill_3: string = "";
   count: number = 0;
   budget: number = 0;

   
}