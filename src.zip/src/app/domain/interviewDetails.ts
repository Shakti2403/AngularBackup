import { ApplicantDetails } from "./applicant";
import { EmployeeDetails } from "./employeedetails";

export class InterviewDetails{
    interviewId : number =0;
    applicantDetails : ApplicantDetails = new ApplicantDetails();
    employeeDetails :  EmployeeDetails = new EmployeeDetails();
    feedback : string ="";
    status : string = "";
}