export class SendMail{
    
    recipient : string ="";
    msgBody : string ="";
    subject : string ="";
  
}