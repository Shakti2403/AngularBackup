import { EmployeeDetails } from "./employeedetails";
import { ProjectDetails } from "./projectdetails";

export class Login{
   
    
    userId : number=0;
    userPassword :string = "";
    designation : string ="";
  
}