import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-menu-page',
  templateUrl: './hr-menu-page.component.html',
  styleUrls: ['./hr-menu-page.component.css']
})
export class HrMenuPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
