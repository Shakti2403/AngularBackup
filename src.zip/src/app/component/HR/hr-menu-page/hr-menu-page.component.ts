import { Component, OnInit } from '@angular/core';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { JobRequest } from 'src/app/domain/jobrequest';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-hr-menu-page',
  templateUrl: './hr-menu-page.component.html',
  styleUrls: ['./hr-menu-page.component.css']
})
export class HrMenuPageComponent implements OnInit {

  interviewDetails : InterviewDetails[] = [];
  constructor(private interviewCrudService : InterviewCrudService) { }
  
  ngOnInit(): void {
  }

  getInterviewDetailsByStatus()
  {
    this.interviewCrudService.getInterviewDetailsByStatus().subscribe(
      data =>{
         this.interviewDetails = data;
         console.log(this.interviewDetails);
         
      }
    );
  }
    



  
 
}
