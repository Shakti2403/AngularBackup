import { Component, OnInit } from '@angular/core';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-selected-candidates',
  templateUrl: './selected-candidates.component.html',
  styleUrls: ['./selected-candidates.component.css']
})
export class SelectedCandidatesComponent implements OnInit {
   
  interviewDetails : InterviewDetails[] = [];
  constructor(private interviewCrudService : InterviewCrudService) { }
  
  ngOnInit(): void {
  }

  getInterviewDetailsByStatus()
  {
    console.log("in getInterviewDetailsByStatus");
    
    this.interviewCrudService.getInterviewDetailsByStatus().subscribe(
      data =>{
         this.interviewDetails = data;
         console.log(this.interviewDetails);
         
      }
    );
  }
    

}
