import { Component, OnInit } from '@angular/core';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.css']
})
export class ApplicantDetailsComponent implements OnInit {
  result: boolean = false;
  applicantDetails: ApplicantDetails[] = [];

  constructor(private applicantCrudService: ApplicantCrudService, private interviewCrudService: InterviewCrudService) { }

  interviewDetails: InterviewDetails = new InterviewDetails();
  applicantDetailsStatus : ApplicantDetails = new ApplicantDetails();
  ngOnInit(): void {
    
    this.getAlApplicantDetails();

  }

  getAlApplicantDetails() {
    this.applicantCrudService.getAlApplicantDetails().subscribe(
      data => {
        this.applicantDetails = data;
        console.log(this.applicantDetails);
      }
    );
  }

  setInterviewer(applicantDetails: ApplicantDetails) {
    console.log("in setInterviewer");
    console.log(applicantDetails);
    this.interviewDetails.applicantDetails.applicantId = applicantDetails.applicantId;
    this.interviewCrudService.setInterviewer(this.interviewDetails).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        this.UpdateApplicantStatus(applicantDetails);
        this.getAlApplicantDetails();
      }
    );
  }

  UpdateApplicantStatus(applicantDetails : ApplicantDetails)
  {
    this.applicantCrudService.UpdateApplicantStatus(applicantDetails).subscribe(
      data => {
         this.result = data;
         console.log(this.result);
      }
    ); 
  }



}
