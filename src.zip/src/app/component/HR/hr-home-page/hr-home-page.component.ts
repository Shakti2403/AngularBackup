import { Component, OnInit } from '@angular/core';

@Component
({
  selector: 'app-hr-home-page',
  templateUrl: './hr-home-page.component.html',
  styleUrls: ['./hr-home-page.component.css']
})
export class HrHomePageComponent implements OnInit {

  constructor() { }
  
  ngOnInit(): void {
  }

}
