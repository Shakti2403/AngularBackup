import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-application-form',
  templateUrl: './candidate-application-form.component.html',
  styleUrls: ['./candidate-application-form.component.css']
})
export class CandidateApplicationFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
