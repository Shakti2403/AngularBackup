import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-request',
  templateUrl: './all-request.component.html',
  styleUrls: ['./all-request.component.css']
})
export class AllRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
