import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobRequest } from 'src/app/domain/jobrequest';
import { Login } from 'src/app/domain/login';
import { ProjectDetails } from 'src/app/domain/projectdetails';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-tl-home-page',
  templateUrl: './tl-home-page.component.html',
  styleUrls: ['./tl-home-page.component.css']
})
export class TlHomePageComponent implements OnInit {


  allRequests: JobRequest[] = [];
  login: Login = new Login();
  projectDetails: ProjectDetails = new ProjectDetails();
  jobRequest: JobRequest = new JobRequest();
  result: boolean = false;

  constructor(private router: Router, private jobRequestCrudService: JobRequestCrudService) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    console.log(this.login);
    this.showAllRequests();
  }

  updateDetails(jobId: number) {
    console.log(jobId);
    this.router.navigate(['updatedetails', jobId]);
  }

  showAllRequests() {
    this.jobRequestCrudService.getAllPendingJobRequests(this.login.userId).subscribe(
      data => {
        this.allRequests = data;
        console.log(this.allRequests);
      }
    );
  }


  DeleteRequest(jobId: number) {
    this.jobRequestCrudService.DeleteRequest(jobId).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        this.reloadPage();

      }
    );
  }

  reloadPage() {
    window.location.reload();
  }



}
