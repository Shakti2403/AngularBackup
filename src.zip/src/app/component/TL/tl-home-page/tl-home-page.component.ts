import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tl-home-page',
  templateUrl: './tl-home-page.component.html',
  styleUrls: ['./tl-home-page.component.css']
})
export class TlHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
