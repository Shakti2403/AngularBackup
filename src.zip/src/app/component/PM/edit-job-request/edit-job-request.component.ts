import { Component, OnInit } from '@angular/core';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-edit-job-request',
  templateUrl: './edit-job-request.component.html',
  styleUrls: ['./edit-job-request.component.css']
})
export class EditJobRequestComponent implements OnInit {

  constructor(private jobRequestCrudService : JobRequestCrudService) { }

  ngOnInit(): void {
  }

  goToEditDetails(jobId : number)
  {
    console.log("In GoToEditDetails");
    console.log(jobId);
    
  }

}
