import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { EmployeeDetails } from 'src/app/domain/employeedetails';
import { JobRequest } from 'src/app/domain/jobrequest';
import { EmployeeServiceService } from 'src/app/service/employee-service.service';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-emp-on-bench',
  templateUrl: './emp-on-bench.component.html',
  styleUrls: ['./emp-on-bench.component.css']
})
export class EmpOnBenchComponent implements OnInit {

  jobId: number = 0;
  employeeOnBench: EmployeeDetails[] = [];
  JobRequest: JobRequest = new JobRequest();
  jobReq : JobRequest[] =[];
  result : boolean = false;

  constructor(private activatedRouter: ActivatedRoute, private router: Router,
    private employeeCrudservice: EmployeeServiceService,
    private jobCrudService : JobRequestCrudService
  ) { }

  ngOnInit(): void {

    this.jobId = this.activatedRouter.snapshot.params['jobId'];
    console.log(this.jobId);
    this.reload();
  }

  reload(){
    this.employeeCrudservice.getAllEmployeesOnBench(this.jobId).subscribe(
      data => {
        this.employeeOnBench = data;
        console.log(this.employeeOnBench);
        this.loadJobRequest();
      }
    );
  }

  assignJobId(employee: EmployeeDetails) {
    console.log(employee);
    console.log(this.JobRequest);  
    employee.projectDetails.projectId = this.JobRequest.projectDetails.projectId;
    employee.mgr = this.JobRequest.employeeDetails.employeeId;
    employee.bench = "No";
    console.log(employee);
    this.employeeCrudservice.updateEmployeeDetails(employee).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        this.reload();
      }
    );    
  }

  loadJobRequest(){
    this.jobCrudService.getJobByJobId(this.jobId).subscribe(
      data => {
        this.JobRequest = data;
        console.log(this.JobRequest);
      }
    );
  }

  UpdateJobRequestCount() 
  {
    this.jobCrudService.UpdateJobRequestCount(this.JobRequest).subscribe(
      data => {
          this.JobRequest = data;
          console.log(this.JobRequest);
          this.reload();
      }
    );
  }

  UpdateRequestStatus()
  {
    this.jobCrudService.UpdateRequestStatus(this.JobRequest).subscribe(
      data => {
          this.JobRequest = data;
          console.log(this.JobRequest);
          this.reload();
      }
    );
  }


}
