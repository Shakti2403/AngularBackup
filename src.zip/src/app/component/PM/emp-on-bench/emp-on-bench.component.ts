import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-on-bench',
  templateUrl: './emp-on-bench.component.html',
  styleUrls: ['./emp-on-bench.component.css']
})
export class EmpOnBenchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
