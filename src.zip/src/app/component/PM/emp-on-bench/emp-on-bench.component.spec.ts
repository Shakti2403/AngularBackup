import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpOnBenchComponent } from './emp-on-bench.component';

describe('EmpOnBenchComponent', () => {
  let component: EmpOnBenchComponent;
  let fixture: ComponentFixture<EmpOnBenchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpOnBenchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpOnBenchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
