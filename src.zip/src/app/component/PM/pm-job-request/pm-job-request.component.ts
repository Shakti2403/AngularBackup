import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/domain/employeedetails';
import { JobRequest } from 'src/app/domain/jobrequest';
import { Login } from 'src/app/domain/login';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-pm-job-request',
  templateUrl: './pm-job-request.component.html',
  styleUrls: ['./pm-job-request.component.css']
})
export class PmJobRequestComponent implements OnInit {
  login : Login = new Login();
  allJobRequests : JobRequest[] =[];

  constructor(private jobRequestCrudService : JobRequestCrudService , private router :Router) { }

  ngOnInit(): void
   {
    this.login= JSON.parse(sessionStorage.getItem('login')|| '{}');
    console.log(this.login); 
    this.jobRequestCrudService.getDetailsByLoginId(this.login.userId).subscribe(
      data => 
      {  
        this.allJobRequests  = data;
        console.log(this.allJobRequests);        
      }
    );
  }

  showEmpOnBench(jobId : number)
  {
    console.log("In Emp ON Bench");
      console.log(jobId);
      this.router.navigate(['employeeonbench',jobId]);   
  }

}
