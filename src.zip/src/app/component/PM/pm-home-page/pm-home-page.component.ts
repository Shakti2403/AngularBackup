import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pm-home-page',
  templateUrl: './pm-home-page.component.html',
  styleUrls: ['./pm-home-page.component.css']
})
export class PmHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
