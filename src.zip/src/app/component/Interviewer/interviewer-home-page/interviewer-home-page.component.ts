import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-interviewer-home-page',
  templateUrl: './interviewer-home-page.component.html',
  styleUrls: ['./interviewer-home-page.component.css']
})
export class InterviewerHomePageComponent implements OnInit {

  constructor(private interviewCrudService: InterviewCrudService,
    private applicantCrudService: ApplicantCrudService,
    private router: Router) { }
  interviewDetails: InterviewDetails = new InterviewDetails();
  result: boolean = false;
  applicantDetails: ApplicantDetails = new ApplicantDetails();
  selectedForInterview: ApplicantDetails[] = [];
  employeeId: number = 0;

  ngOnInit(): void {
    this.getApplicantDetailsByStatus();

  }

  getApplicantDetailsByStatus() {
    this.applicantCrudService.getApplicantDetailsByStatus().subscribe(
      data => {
        this.selectedForInterview = data;
        console.log(this.selectedForInterview);
      }
    );
  }
  goTOFeedBackForm() {
    this.router.navigate(['gotofeedbackform']);
  }

  showSelectedCandidate(selected: ApplicantDetails) {
    sessionStorage.setItem('applicantdetails', JSON.stringify(selected));
    this.router.navigate(['gotofeedbackform']);
  }

}
