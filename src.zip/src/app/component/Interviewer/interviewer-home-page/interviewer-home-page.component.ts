import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviewer-home-page',
  templateUrl: './interviewer-home-page.component.html',
  styleUrls: ['./interviewer-home-page.component.css']
})
export class InterviewerHomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
