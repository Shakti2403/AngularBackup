import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/domain/employeedetails';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { Login } from 'src/app/domain/login';
import { EmployeeServiceService } from 'src/app/service/employee-service.service';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit {
  status: string[] = ['Selected', 'Not Selected'];
  details: InterviewDetails = new InterviewDetails();
  result: boolean = false;
  applicantId: number = 0;
  employeeId: number = 0;
  login: Login = new Login();
  employeeDetails: EmployeeDetails = new EmployeeDetails();

  constructor(private router: Router, private interviewCrudService: InterviewCrudService, private activateRoute: ActivatedRoute, private employeeCrudService: EmployeeServiceService) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    console.log(this.login);
    this.applicantId = this.activateRoute.snapshot.params['applicantId'];
    console.log(this.applicantId);
    this.details.applicantDetails.applicantId = this.applicantId;
    this.employeeId = this.activateRoute.snapshot.params['employeeId'];
    console.log(this.employeeId);
    this.details.employeeDetails.employeeId = this.employeeId;
  }

  candidateFeedback() {
    this.interviewCrudService.candidateFeedback(this.details).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        console.log(this.details);

        this.interviewCrudService.UpdateCandidateStatus(this.details).subscribe(
          data => {
            this.result = data;
            console.log(this.result);
            console.log(this.details);
            console.log(this.result);

          }
        );
        this.router.navigate(['interviewerhomepage']);
      }
    );
  }

  getEmployeeDetailsByLoginId() {
    console.log("in getEmployeeDetailsByLoginId()");

    this.employeeCrudService.getEmployeeDetailsByLoginId(this.login.userId).subscribe(
      data => {
        this.employeeDetails = data;
        console.log(this.employeeDetails.employeeId);
      }
    );
  }

  goToHome() {
    this.router.navigate(['gotoInterviewerhomepage']);
  }


}
