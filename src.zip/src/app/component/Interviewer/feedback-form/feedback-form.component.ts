import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { EmployeeDetails } from 'src/app/domain/employeedetails';
import { InterviewDetails } from 'src/app/domain/interviewDetails';
import { Login } from 'src/app/domain/login';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';
import { EmployeeServiceService } from 'src/app/service/employee-service.service';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit {
  status: string[] = ['Selected', 'Not Selected'];
  details: InterviewDetails = new InterviewDetails();
  result: boolean = false;
  applicantId: number = 0;
  employeeId: number = 0;
  login: Login = new Login();
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  applicantDetails : ApplicantDetails = new ApplicantDetails();

  constructor(private router: Router, private interviewCrudService: InterviewCrudService, private activateRoute: ActivatedRoute, private applicantService: ApplicantCrudService) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    console.log(this.login);
    this.applicantDetails = JSON.parse(sessionStorage.getItem('applicantdetails') || '{}');
    this.details.applicantDetails = this.applicantDetails;
    console.log(this.applicantDetails);
    
  }

  candidateFeedback() {
    console.log(this.details);
    
    this.interviewCrudService.candidateFeedback(this.details).subscribe(
      data => {
        this.details = data;
        console.log(this.result);
        console.log(this.details); 

        this.applicantService.UpdateSelectedApplicantStatus(this.applicantDetails).subscribe(
          data => {
            this.result = data;
            console.log(this.result);
            console.log(this.details);
            console.log(this.result);
          }
        );
        this.router.navigate(['interviewerhomepage']);
      }
    );
  }

  goToHome() {
    this.router.navigate(['gotoInterviewerhomepage']);
  }


}
