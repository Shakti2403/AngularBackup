import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewerMenuPageComponent } from './interviewer-menu-page.component';

describe('InterviewerMenuPageComponent', () => {
  let component: InterviewerMenuPageComponent;
  let fixture: ComponentFixture<InterviewerMenuPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterviewerMenuPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InterviewerMenuPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
