import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { JobRequest } from 'src/app/domain/jobrequest';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';
import { InterviewCrudService } from 'src/app/service/interview-crud.service';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-candidate-application-form',
  templateUrl: './candidate-application-form.component.html',
  styleUrls: ['./candidate-application-form.component.css']
})
export class CandidateApplicationFormComponent implements OnInit {

  skills: string[] = ['Java', 'Python', 'C++'];
  qualification: string[] = ['B.E', 'B.SC', 'MCA', 'BTECH'];
  experience: string[] = ['Freshers', '1-2 years', '3-5 years'];
  location: string[] = ['Mumbai', 'Badlapur', 'Work From Home'];
  jobRequest: JobRequest[] = [];
  applicantdetails: ApplicantDetails = new ApplicantDetails();
  result: boolean = false;
  submitted: boolean = false;

  constructor(private router: Router, private applicantCrudService:
    ApplicantCrudService) { }

  ngOnInit(): void {
  }

  goToCandidateForm() {
    this.router.navigate(['candidateform']);
  }

  addNewApplicantDetails() {
    this.applicantCrudService.addNewApplicantDetails(this.applicantdetails).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
        console.log(this.applicantdetails);
        this.submitted = true;
      }
    );
  }

  backToHome() {
    this.router.navigate(['backtohome']);
  }
}
