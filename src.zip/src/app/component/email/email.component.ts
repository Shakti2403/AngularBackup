import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { SendMail } from 'src/app/domain/sendmail';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';
import { MailSenderService } from 'src/app/service/mail-sender.service';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent implements OnInit {
 
  mail : SendMail = new SendMail();
  applicant : ApplicantDetails = new ApplicantDetails();
  submitted: boolean = false;
  result : string = "";

  applicantId : number = 0;
  constructor(private route:Router,
    private activateRoute : ActivatedRoute,
    private applicantCrudService : ApplicantCrudService,
    private mailSenderService : MailSenderService) { }
 
  
  ngOnInit(): void 
  {}
  
  SendEmail()
  {
   console.log(this.mail);
   this.mailSenderService.emailSender(this.mail).subscribe(
    data =>{
      this.result = data;
      console.log(this.result);
      this.submitted =true;
    }
   ); 

  
  }

  backToHome(){
    this.route.navigate(['selectedcandidates']);
  }

   

}
