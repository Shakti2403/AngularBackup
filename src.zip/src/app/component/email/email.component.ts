import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { SendMail } from 'src/app/domain/sendmail';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent implements OnInit {
 
  mail : SendMail = new SendMail();
  submitted: boolean = false;
  constructor(private route:Router) { }
 
  
  ngOnInit(): void {
  }
  
  SendEmail()
  {
   console.log(this.mail);  
  }

  // onSubmit(contactForm: NgForm) {
  //   if (contactForm.valid) {
  //     const email = contactForm.value;
  //     const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //     this.http.post('https://formspree.io/asdlf7asdf',
  //       { name: email.name, replyto: email.email, message: email.messages },
  //       { 'headers': headers }).subscribe(
  //         response => {
  //           console.log(response);
  //         }
  //       );
  //   }
  // }

}
