import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SendMail } from '../domain/sendmail';

@Injectable({
  providedIn: 'root'
})
export class MailSenderService {
  baseURL: string = "http://localhost:8080/emailSenderapi";
  constructor(private httpClient: HttpClient) { }

  emailSender(sendmail: SendMail): Observable<string> {
    return this.httpClient.post<string>(this.baseURL + "/sendMailWithAttachment", sendmail);
  }
}
