import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicantDetails } from '../domain/applicant';


@Injectable({
  providedIn: 'root'
})
export class ApplicantCrudService {

  baseURL: string = "http://localhost:8080/applicantdetailsapi";
  constructor(private httpClient: HttpClient) { }
  
addNewApplicantDetails(applicantdetails : ApplicantDetails) : Observable<boolean>
{
   return this.httpClient.post<boolean>(this.baseURL+"/insertnewapplicant" , applicantdetails);
}

getAlApplicantDetails() : Observable<ApplicantDetails[]>
{
  return this.httpClient.get<ApplicantDetails[]>(this.baseURL + "/applicantdetails/all");
}

UpdateApplicantStatus(applicantDetails : ApplicantDetails) : Observable<boolean>
{
  return this.httpClient.put<boolean>(this.baseURL + "/updateapplicantdetailsbyapplicantid",applicantDetails);
}

UpdateSelectedApplicantStatus(applicantDetails : ApplicantDetails) : Observable<boolean>
{
  return this.httpClient.put<boolean>(this.baseURL + "/updateselectedapplicantdetailsbyapplicantid",applicantDetails);
}

getApplicantDetailsByStatus() : Observable<ApplicantDetails[]>{
  return this.httpClient.get<ApplicantDetails[]>(this.baseURL + "/applicantdetailsbystatus/all");
}

}



