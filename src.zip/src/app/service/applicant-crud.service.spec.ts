import { TestBed } from '@angular/core/testing';

import { ApplicantCrudService } from './applicant-crud.service';

describe('ApplicantCrudService', () => {
  let service: ApplicantCrudService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApplicantCrudService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
