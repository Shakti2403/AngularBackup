import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../domain/employeedetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService
 {
  baseURL :string ="http://localhost:8080/employeeapi/employee/";
  constructor(private httpClient : HttpClient) { }


  GetEmployeeByEmployeeId(userId : number) : Observable<EmployeeDetails>
   {
      return this.httpClient.get<EmployeeDetails>(this.baseURL + userId);
   }

 }
