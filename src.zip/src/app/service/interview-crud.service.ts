import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InterviewDetails } from '../domain/interviewDetails';

@Injectable({
  providedIn: 'root'
})
export class InterviewCrudService {

  private baseURL: string = "http://localhost:8080/interviewdetailsapi";

  constructor(private httpClient: HttpClient) { }


  setInterviewer(interviewDetails: InterviewDetails): Observable<boolean> {
    return this.httpClient.post<boolean>(this.baseURL + "/insertnewinterviewdetails", interviewDetails);
  }

  getInterviewDetailsByStatus(): Observable<InterviewDetails[]> {
    return this.httpClient.get<InterviewDetails[]>(this.baseURL + "/interviewdetailsbystatus/all");
  }

  candidateFeedback(interviewDetails: InterviewDetails): Observable<InterviewDetails> {
    return this.httpClient.post<InterviewDetails>(this.baseURL + "/insertnewinterviewdetails", interviewDetails);
  }

  //  Updataing status from "sent for interview" to "selected'
  UpdateCandidateStatus(interviewDetails: InterviewDetails): Observable<boolean> {
    console.log("in Candidate Update Service");

    return this.httpClient.put<boolean>(this.baseURL + "/updateinterviewdetailsbyinterviewid", interviewDetails);
  }

  //Updataing status from "selected" to "pass'

  UpdateSelectedToPass(interviewDetails: InterviewDetails): Observable<boolean> {
    return this.httpClient.put<boolean>(this.baseURL + "/updateinterviewdetailsstatus", interviewDetails);
  }



}
