import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InterviewDetails } from '../domain/interviewDetails';

@Injectable({
  providedIn: 'root'
})
export class InterviewCrudService {

  private baseURL: string = "http://localhost:8080/interviewdetailsapi";

  constructor(private httpClient: HttpClient) { }


  setInterviewer(interviewDetails: InterviewDetails): Observable<boolean> {
    return this.httpClient.post<boolean>(this.baseURL + "/insertnewinterviewdetails", interviewDetails);
  }

  getInterviewDetailsByStatus() : Observable<InterviewDetails[]>
  {
     return this.httpClient.get<InterviewDetails[]>(this.baseURL+"/interviewdetailsbystatus/all");
  }

  candidateFeedback(interviewDetails : InterviewDetails) : Observable<boolean>
  {
    return this.httpClient.post<boolean>(this.baseURL+"/insertnewinterviewdetails",interviewDetails);
  }
}
