import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../domain/employeedetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService
 {
  baseURL :string ="http://localhost:8080/employeeapi";
  constructor(private httpClient : HttpClient) { }


  GetEmployeeByEmployeeId(userId : number) : Observable<EmployeeDetails>
   {
      return this.httpClient.get<EmployeeDetails>(this.baseURL+"/employee/" + userId);
   }

   getAllEmployeesOnBench(jobId : number) : Observable<EmployeeDetails[]>
   {
   return this.httpClient.get<EmployeeDetails[]>(this.baseURL+"/employeematchingskills/"+ jobId);
   }

   updateEmployeeDetails(employee: EmployeeDetails) : Observable<boolean> {
    console.log("in service");
    console.log(employee);
    
    return this.httpClient.put<boolean>(this.baseURL + '/employeedetailsassign' , employee );
   }
   
   getEmployeeDetailsByLoginId(employeeId : number) : Observable<EmployeeDetails>
   {
     return this.httpClient.get<EmployeeDetails>(this.baseURL+"employee/"+employeeId);
     
   }



 }
