import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JobRequest } from 'src/app/domain/jobrequest';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component
  ({
    selector: 'app-hr-home-page',
    templateUrl: './hr-home-page.component.html',
    styleUrls: ['./hr-home-page.component.css']
  })
export class HrHomePageComponent implements OnInit {
  jobReq: JobRequest[] = [];
  jobRequest: JobRequest = new JobRequest();
  result: boolean = false;


  constructor(private activatedRouter: ActivatedRoute, private router: Router,
    private jobreqcrudservice: JobRequestCrudService) { }

  ngOnInit(): void {
    console.log("in hr componant");
    this.sendToHR();
  
  }

  sendToHR() {
    console.log("in HR componant");
    this.jobreqcrudservice.SendToHR().subscribe(
      data => {
        this.jobReq = data;
        console.log(this.jobReq);
      }
    );
  }

  SendJobToCareerPage(jobRequest: JobRequest) {
    console.log("in SendJobToCareerPage()");
    console.log(this.jobRequest.jobId);
    // this.jobRequest.status="Published";
    this.jobreqcrudservice.SendJobToCareerPage(jobRequest).subscribe(
      data => {
        this.result = data;
        console.log(this.result);
       
      }
    );
    this.reloadPage();
  }


  reloadPage()
  {
      window.location.reload();
  }


}
